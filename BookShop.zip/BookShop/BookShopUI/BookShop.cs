﻿using BookShopLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BookShopUI
{
    public partial class BookShop : Form
    {
        private BookstoreService store = new BookstoreService(@"http://www.contribe.se/arbetsprov-net/books.json");
        BindingSource itemsBinding = new BindingSource(); // Bindingsource for the items

        private List<Book> shoppingCartData = new List<Book>();
        BindingSource cartBinding=new BindingSource(); // Bindingsource for the shoppingcart

        public BookShop()
        {
            InitializeComponent();
            SetUpData("");

            itemsBinding.DataSource = store.Items.Where(x=>x.inStock!=0).ToList(); // Links the items to the listbox Store Items
            itemsListbox.DataSource = itemsBinding;

            itemsListbox.DisplayMember = "Display"; // Data that is displayed in Store Items
            itemsListbox.ValueMember = "Display";

            cartBinding.DataSource = shoppingCartData; // Links the items to the listbox Shoping Cart
            shoppingCartListbox.DataSource = cartBinding;

            shoppingCartListbox.DisplayMember= "DisplayCart";
            shoppingCartListbox.ValueMember = "DisplayCart";

        }
        public async void SetUpData(string searchWord)
        {
            
            IEnumerable<IBook> collectionBooks = await store.GetBooksAsync(searchWord);
            store.Items = collectionBooks.Cast<Book>().ToList(); // cast from IBook to Book for the listBox
        }
        private void addToCart_Click(object sender, EventArgs e)
        {
            Book selectedItem = (Book)itemsListbox.SelectedItem;
            bool inShoppingCart = false;
            foreach (Book b in shoppingCartData) // If the book exists update it
            {
                if (b.Author == selectedItem.Author && b.Title == selectedItem.Title && b.Price == selectedItem.Price)
                {
                    b.inCart =b.inCart +1;
                    inShoppingCart = true;
                    break;
                }
            }
            if (!inShoppingCart) // if the book don't exists create a new
            {
                selectedItem.inCart = 1;
                shoppingCartData.Add(selectedItem);
            }
            selectedItem.inStock -= 1;
            itemsBinding.DataSource = store.Items.Where(x => x.inStock != 0).ToList();
            itemsBinding.ResetBindings(false);
            cartBinding.ResetBindings(false);
        }

        private void makePurchase_Click(object sender, EventArgs e)
        {
            // Calculate the total sum and and print out the books in a messagebox
            decimal sum = 0;
            string displayString="The folowing books were purchased:\n\n";
            foreach(Book book in shoppingCartData)
            {
                displayString += book.Title + " by " + book.Author + "\n";
                sum = sum + book.inCart * book.Price;
            }

            displayString += "\nThe total cost for the books: " + sum.ToString("#,##") + " kr";
           
            shoppingCartData.Clear();
            cartBinding.ResetBindings(false);
            MessageBox.Show(displayString);
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            SetUpData(searchBox.Text);
            itemsBinding.DataSource = store.Items.Where(x => x.inStock != 0).ToList();
            itemsBinding.ResetBindings(false);
        }
    }
}
