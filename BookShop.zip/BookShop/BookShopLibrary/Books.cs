﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShopLibrary
{
    // This class is a List of the class Book, it is used when we read data from books.json
    public class Books
    {
        public List<Book> books;
    }
}
