﻿using Newtonsoft.Json; // Added for the jsonConvert, from Newtonsoft.Json framework on NuGet
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net; // Added for the WebClinet
using System.Text;
using System.Threading.Tasks;

namespace BookShopLibrary
{
    public class BookstoreService : IBookstoreService
    {
        private string url;  // the url to the JSON-file
        private string json; // The JSON text
        public List<Book> Items { get; set; }

        // Constructor, sets the url to the JSON-file: books.json 
        public BookstoreService(string jsonURL)
        {
            url = jsonURL;
            Items = new List<Book>();
        }

        // A search-function that filters the list of books on Title and Author
        public async Task<IEnumerable<IBook>> GetBooksAsync(string searchString)
        {
                json = new WebClient().DownloadString(url); // Downloads the JSON-text
            
            byte[] data = Encoding.Default.GetBytes(json); // Change the text to UTF8
            json = Encoding.UTF8.GetString(data);

            Books booksFromList = JsonConvert.DeserializeObject<Books>(json); // Get all the books from the JSON-file
            List<Book> searchList = new List<Book>();
            // Search the list of books for the keywords and if match adds them to a list
            foreach (Book b in booksFromList.books)
            {
                if (b.Author.ToLower().Contains(searchString.ToLower()) || b.Title.ToLower().Contains(searchString.ToLower()))
                    searchList.Add(b);
            }

            return searchList;
        }

    }
}
