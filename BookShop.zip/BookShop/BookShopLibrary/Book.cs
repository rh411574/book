﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookShopLibrary
{
    // Books with the same title, author and price is grouped in this class
    public class Book : IBook
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public decimal Price { get; set; }
        public int inStock { get; set; }
        public int inCart { get; set; }
        public string Display
        {
            get
            {
                return string.Format("{0} by {1} - {2:0.00} kr (in stock: {3})", Title, Author, Price, inStock);
            }
        }
        public string DisplayCart
        {
            get
            {
                return string.Format("{0} by {1} - {2:0.00} kr (in cart: {3})", Title, Author, Price, inCart);
            }
        }

    }
}
